
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

/**
 * Created by Menobia on 29/03/2017.
 */
/* Menobia Arif BESE 5B Geo CIty
LAB 10
CIty SEARCH 3
 */
public class Main {


    public static void main(final String[] args) throws Exception {

/* Menobia Arif BESE 5B Geo CIty
LAB 10
CIty SEARCH 3
 */
        String csvFile = "src/GeoLiteCity-Location.csv";
       // manageLocations ml = new manageLocations();
        BufferedReader br = null;
        String line = "";
        String cvsSplitBy = ",";
        String[] Line;
        String[] temp;
            br = new BufferedReader(new FileReader(csvFile));
            int lineNo = 0;
            while ((line = br.readLine()) != null) {
                lineNo++;
                if (lineNo > 2) {
                    temp = line.split(cvsSplitBy);
                    System.out.println(line);
                    if (temp.length <= 7) {
                        int id = Integer.parseInt(temp[0]);
                        String country = temp[1].replace("\"", "");
                        String region = temp[2].replace("\"", "");
                        String city = temp[3].replace("\"", "");
                        String postalCode = temp[4].replace("\"", "");
                        float lon = Float.parseFloat(temp[5]);
                        float lat = Float.parseFloat(temp[6].replace("\"", ""));
/* Menobia Arif BESE 5B Geo CIty
LAB 10
CIty SEARCH 3
 */
                       // ml.addEntry7(id, country, region, city, postalCode, lat, lon);
                    } else {
                        int id = Integer.parseInt(temp[0]);
                        String country = temp[1].replace("\"", "");
                        String region = temp[2].replace("\"", "");
                        String city = temp[3].replace("\"", "");
                        String postalCode = temp[4].replace("\"", "");
                        float lon = Float.parseFloat(temp[5]);
                        float lat = Float.parseFloat(temp[6].replace("\"", ""));

                        int metroCode;
                        if (temp[7].length() > 0)
                            metroCode = Integer.parseInt(temp[7]);
                        else
                            metroCode = 0;

                        int areaCode = 0;
                        if (temp.length > 8) {
                            if (temp[8].length() > 0)
                                areaCode = Integer.parseInt(temp[8]);
                            else
                                areaCode = 0;
                        }
/* Menobia Arif BESE 5B Geo CIty
LAB 10
CIty SEARCH 3
 */

                        //ml.addEntry9(id, country, region, city, postalCode, lat, lon, metroCode, areaCode);
                    }
                }
            }
    }
}







